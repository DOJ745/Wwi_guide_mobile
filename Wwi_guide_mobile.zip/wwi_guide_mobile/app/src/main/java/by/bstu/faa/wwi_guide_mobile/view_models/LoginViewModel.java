package by.bstu.faa.wwi_guide_mobile.view_models;

public class LoginViewModel {
}
