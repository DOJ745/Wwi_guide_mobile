package by.bstu.faa.wwi_guide_mobile.data_objects.entities;

public class Year {

}
