package by.bstu.faa.wwi_guide_mobile.data_objects.dto;

public class AchievementDto {
}
