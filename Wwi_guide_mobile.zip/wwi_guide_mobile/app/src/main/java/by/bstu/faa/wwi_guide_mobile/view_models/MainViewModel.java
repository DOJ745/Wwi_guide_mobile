package by.bstu.faa.wwi_guide_mobile.view_models;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}